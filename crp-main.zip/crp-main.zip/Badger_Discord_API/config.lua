Config = {
	Guild_ID = '760619371310612511',
	Bot_Token = 'ODU5OTM4MTE3ODMzMzI2NjEy.YNz9yA.gfKwCLjgCPQz6H-1dKUrXgHvpBg	',
	RoleList = {        
	['Member'] = 867834012479258625,
	['Dev'] = 807185688260902942,
	['MCSO'] = 807185460489093151,
	['HTPD'] = 807185300903559178,
	['NJSP'] = 760621388628230146,
	['CertCop'] = 820064498823069756,
	['Donator'] = 875118671989735434,
	['Staff'] = 807186165392211979,
	['Tmod'] = 807628771908780034,
	['Moderator'] = 807628458691526676,
	['Admin'] = 807185895265402880,
	['HAdmin'] = 838928962684059678,
	['CManager'] = 810350915974201344,
	['Owner'] = 760620798841978910,
	},
}

Config.Splash = {
	Header_IMG = 'https://cdn.discordapp.com/attachments/870190860027977788/875119940355649566/mercer_county-01-1.png',
	Enabled = true,
	Wait = 10, -- How many seconds should splash page be shown for? (Max is 12)
	Heading1 = "Welcome to [MCNJSRP]",
	Heading2 = "Make sure to join our Discord and check out our website!",
	Discord_Link = 'https://discord.gg/kX4rxeD9qP',
	Website_Link = '',
}