Config = {
	prefix = "^7[^1Badger-Priorities^7] ^3",
	Options = {
		EnableSpeedMessage = true,
		EnablePCDMessage = true,
		EnableHoldMessage = true,
		EnableProgressMessage = true,
		EnableCooldownMessage = true,
		AlwaysDisplay = true, -- Always display the priority cooldown text even with 0 mins left?
		CooldownDisplay = "~p~Priority Cooldown: ~w~{MINS} ~w~mins",
		InProgressDisplay = "~p~Priority in Progress",
		OnHoldDisplay = "~p~Priorities are on Hold",
		-- TooFastDisplay triggers when a car is going over 80 MPH and priorities are in progress, on hold, or a cooldown is active 
		TooFastDisplay = "~r~NOTICE: ~b~You cannot run from police currently. You are risking staff punishment!",
		resetDisplay = "~p~Priorities are ~w~Available"
	},
	Messages = {
		CooldownMessage = 'A priority was just conducted... The cooldown has been activated. ' -- You can also use {MINS} parameter here
		.. '^1You cannot run from police or cause any priorities (violent RP) until the cooldown has concluded!',
		InProgressMessage = 'There is a priority in progress... ^1You cannot run from police or cause any priorities (violent RP) until priorities are off hold!',
		OnHoldMessage = 'Priorities are now on hold... ^1You cannot run from police or cause any priorities (violent RP) until priorities are off hold!',
		resetMessage = 'Priorities Have Been Reset! ^7You Can Do Priorities!'
	}, 
	DisplayLocation = {
		x = .21,
		y = .830
	}
}